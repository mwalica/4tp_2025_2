package ch.walica.temp120925_4tp2_spinner;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ch.walica.temp120925_4tp2_spinner.model.Person;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner1, spinner2;
    private TextView tvResult1, tvResult2;
    private String selectedColor;
    private String[] names = {"Roman", "Karol", "Jan"};
    private Person[] people = {
            new Person("Jan", 34),
            new Person("Adam", 22),
            new Person("Gustaw", 42),
    };
    private Person selectedName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spinner1 = findViewById(R.id.spinner1);
        spinner2 = findViewById(R.id.spinner2);
        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);
//spinner1
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedColor = spinner1.getSelectedItem().toString();
                switch (selectedColor) {
                    case "Czerwony":
                        tvResult1.setTextColor(getColor(R.color.red));
                        break;
                    case "Zielony":
                        tvResult1.setTextColor(getColor(R.color.green));
                        break;
                    case "Niebieski":
                        tvResult1.setTextColor(getColor(R.color.blue));
                        break;
                }
                tvResult1.setText(selectedColor);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //spinner 2
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, names);
        ArrayAdapter<Person> adapter2 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, people);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //selectedName = spinner2.getSelectedItem().toString();
                selectedName = people[i];
                tvResult2.setText(selectedName.getName() + " " + selectedName.getAge());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }
}