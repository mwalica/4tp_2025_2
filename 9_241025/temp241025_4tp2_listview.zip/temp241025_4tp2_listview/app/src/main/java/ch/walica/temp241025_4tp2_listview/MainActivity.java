package ch.walica.temp241025_4tp2_listview;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private String[] names = {"Jan", "Karol", "Gustaw", "Dominik", "Adam", "Lucjan", "Jan", "Karol", "Gustaw", "Dominik", "Adam", "Lucjan", "Jan", "Karol", "Gustaw", "Dominik", "Adam", "Lucjan", "Jan", "Karol", "Gustaw", "Dominik", "Adam", "Lucjan"};
    private Person[] people = {
            new Person("Jan", 56),
            new Person("Gustaw", 46),
            new Person("Konrad", 36),
            new Person("Alicja", 26),
            new Person("Ela", 65),
            new Person("Karol", 43),
            new Person("Marek", 58),
            new Person("Adam", 136),
            new Person("Iza", 24),
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);

        //ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, names);
        ArrayAdapter<Person> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.text_view_item, R.id.tvName,people);


        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, "Kliknęto: " + people[i].name(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}