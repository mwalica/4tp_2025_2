package ch.walica.temp241025_4tp2_listview;

import androidx.annotation.NonNull;

public record Person(String name, int age) {

    @NonNull
    @Override
    public String toString() {
        return name;
    }
}
