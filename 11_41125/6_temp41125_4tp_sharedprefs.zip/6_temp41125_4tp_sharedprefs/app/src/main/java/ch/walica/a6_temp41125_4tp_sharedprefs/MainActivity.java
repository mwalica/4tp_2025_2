package ch.walica.a6_temp41125_4tp_sharedprefs;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class MainActivity extends AppCompatActivity {

    private EditText etName;
    private TextView tvResult;
    private Button btnSave;
    private Button btnClear;
    private SwitchMaterial switchMaterial;
    private ConstraintLayout constraintLayout;

    private String name = "";
    private boolean switchState;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        tvResult = findViewById(R.id.tvResult);
        btnSave = findViewById(R.id.btnSave);
        btnClear = findViewById(R.id.btnClear);
        switchMaterial = findViewById(R.id.switchMaterial);
        constraintLayout = findViewById(R.id.constraintLayout);

        sharedPreferences = getSharedPreferences("shared_prefs_1", MODE_PRIVATE);
        loadSettings();
        updateScreen();

        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                name = charSequence.toString();
                tvResult.setText(name);
            }
        });

        btnSave.setOnClickListener(view -> {
            sharedPreferences.edit().putString("name_key", name).apply();
            Toast.makeText(this, "tekst zapisany", Toast.LENGTH_SHORT).show();
        });

        btnClear.setOnClickListener(view -> {
            sharedPreferences.edit().clear().apply();
            loadSettings();
            updateScreen();
        });

        switchMaterial.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton compoundButton, boolean state) {
                switchState = state;
                if(switchState) {
                    constraintLayout.setBackgroundColor(getColor(R.color.grey));
                } else {
                    constraintLayout.setBackgroundColor(getColor(R.color.white));
                }
                sharedPreferences.edit().putBoolean("switch_key", switchState).apply();
            }
        });

    }

    private void loadSettings() {
        name = sharedPreferences.getString("name_key", "");
        switchState = sharedPreferences.getBoolean("switch_key", false);
    }

    private void updateScreen() {
        tvResult.setText(name);
        switchMaterial.setChecked(switchState);

        if(switchState) {
            constraintLayout.setBackgroundColor(getColor(R.color.grey));
        } else {
            constraintLayout.setBackgroundColor(getColor(R.color.white));
        }
    }
}