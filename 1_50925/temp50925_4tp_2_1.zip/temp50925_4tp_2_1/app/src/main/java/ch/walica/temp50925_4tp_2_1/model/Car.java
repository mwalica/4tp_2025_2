package ch.walica.temp50925_4tp_2_1.model;

import android.os.Parcelable;

import java.io.Serializable;

public class Car implements Serializable {
    private String company;
    private String model;
    private int productionYear;

    public Car(String company, String model, int productionYear) {
        this.company = company;
        this.model = model;
        this.productionYear = productionYear;
    }

    public String getCompany() {
        return company;
    }

    public String getModel() {
        return model;
    }

    public int getProductionYear() {
        return productionYear;
    }
}
