package ch.walica.temp171025_4tp2_fragmenty2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class SecondFragment extends Fragment {

    private Button btnBack;
    private TextView tvResult;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnBack = view.findViewById(R.id.btnBack);
        tvResult = view.findViewById(R.id.tvResult);

        if(getArguments() != null) {
            int num = getArguments().getInt("name_key");
            tvResult.setText(num + "");
        }

        btnBack.setOnClickListener(v -> {
            Fragment firstFragment = new FirstFragment();
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, firstFragment).commit();
        });
    }
}