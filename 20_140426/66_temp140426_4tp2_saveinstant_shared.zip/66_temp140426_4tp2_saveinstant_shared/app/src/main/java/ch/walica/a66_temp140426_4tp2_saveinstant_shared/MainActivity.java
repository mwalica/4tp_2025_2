package ch.walica.a66_temp140426_4tp2_saveinstant_shared;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button btnRandom, btnClear;
    private TextView tvResult;
    private int randomNum = 0;
    private Random random = new Random();
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnClear = findViewById(R.id.btnClear);
        btnRandom = findViewById(R.id.btnRandom);
        tvResult = findViewById(R.id.tvResult);
        sharedPreferences = getSharedPreferences("shared_prefs", MODE_PRIVATE);

        randomNum = sharedPreferences.getInt("random_num_2", 0);

        tvResult.setText(String.valueOf(randomNum));

//        if(savedInstanceState != null) {
//            randomNum = savedInstanceState.getInt("random_num_key");
//            tvResult.setText(String.valueOf(randomNum));
//        }

        btnRandom.setOnClickListener(view -> {
            randomNum = random.nextInt(101) - 50;
            tvResult.setText(String.valueOf(randomNum));
            sharedPreferences.edit().putInt("random_num_2", randomNum).apply();
        });

        btnClear.setOnClickListener(view -> {
            sharedPreferences.edit().clear().apply();
            randomNum = 0;
            tvResult.setText(String.valueOf(randomNum));
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("random_num_key", randomNum);
    }
}