package ch.walica.a31_temp160126_4tp2_json;

import androidx.annotation.NonNull;

public class PersonObj {
    private String firstName;
    private String city;

    public PersonObj(String firstName, String city) {
        this.firstName = firstName;
        this.city = city;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getCity() {
        return city;
    }

    @NonNull
    @Override
    public String toString() {
        return firstName + " " + city;
    }
}
