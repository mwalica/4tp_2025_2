package ch.walica.a31_temp160126_4tp2_json;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class ArrayFragment extends Fragment {

private ListView listView;
private List<PersonObj> people = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_array, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        listView = view.findViewById(R.id.listView);
        ArrayAdapter<PersonObj> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, people);
        listView.setAdapter(adapter);

        try {
            JSONArray peopleArray = new JSONArray(Util.loadJSONFromAssets(requireActivity(), "people.json"));

            for(int i = 0; i < peopleArray.length(); i++) {
                JSONObject personObj = peopleArray.getJSONObject(i);

                String firstName = personObj.getString("firstName");
                int age = personObj.getInt("age");
                JSONObject address = personObj.getJSONObject("address");
                String city = address.getString("city");
                String country = address.getString("country");
                people.add(new PersonObj(firstName, city));

            }



        }catch(JSONException error) {
            Toast.makeText(requireContext(), error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}