package ch.walica.temp90925_4tp_2_radio_animation;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private TextView tvResult;
    private RadioButton selectedRb;
    private int radioSelectedId;

    private Button btnShow, btnHide;
    private View view1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        radioGroup = findViewById(R.id.radioGroup);
        tvResult = findViewById(R.id.tvResult);
        btnShow = findViewById(R.id.btnShow);
        btnHide = findViewById(R.id.btnHide);
        view1 = findViewById(R.id.view1);

        radioSelectedId = radioGroup.getCheckedRadioButtonId();
        selectedRb = findViewById(radioSelectedId);

        selectTextColor();

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull RadioGroup radioGroup, int id) {
                radioSelectedId = id;
                selectedRb = findViewById(radioSelectedId);
                selectTextColor();
            }
        });

        btnShow.setOnClickListener(view -> {
            Animation animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_in);
            view1.startAnimation(animation);
        });

        btnHide.setOnClickListener(view -> {
            Animation animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_out);
            view1.startAnimation(animation);
        });



    }

    private void selectTextColor() {
        tvResult.setText(selectedRb.getText());
        if(radioSelectedId == R.id.rbRed) {
            tvResult.setTextColor(getColor(R.color.red));
        }
        if(radioSelectedId == R.id.rbGreen) {
            tvResult.setTextColor(getColor(R.color.green));
        }
    }
}