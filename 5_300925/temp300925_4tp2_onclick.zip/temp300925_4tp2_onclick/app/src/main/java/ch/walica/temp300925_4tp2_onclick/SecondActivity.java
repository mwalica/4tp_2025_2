package ch.walica.temp300925_4tp2_onclick;

import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener {

    private View viewResult, viewRed, viewGreen, viewBlue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        viewResult = findViewById(R.id.viewResult);
        viewRed = findViewById(R.id.viewRed);
        viewGreen = findViewById(R.id.viewGreen);
        viewBlue = findViewById(R.id.viewBlue);

        viewRed.setOnClickListener(this);
        viewGreen.setOnClickListener(this);
        viewBlue.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        ColorDrawable background = (ColorDrawable) view.getBackground();
//        int bgColor = background.getColor();
//        viewResult.setBackgroundColor(bgColor);
        viewResult.setBackground(background);
    }
}