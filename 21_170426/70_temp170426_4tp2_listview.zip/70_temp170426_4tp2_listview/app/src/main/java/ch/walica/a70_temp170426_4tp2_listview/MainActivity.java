package ch.walica.a70_temp170426_4tp2_listview;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    FloatingActionButton floatingActionButton;
    ListView listView;
    List<String> numbers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        floatingActionButton = findViewById(R.id.floatingActionButton);
        listView = findViewById(R.id.listView);

        numbers.add(23+"");
        numbers.add(String.valueOf(123));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.list_item, numbers);
        listView.setAdapter(adapter);

        floatingActionButton.setOnClickListener(view -> {
            int randomNum = new Random().nextInt(123);
            numbers.add(String.valueOf(randomNum));
            adapter.notifyDataSetChanged();
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                numbers.remove(numbers.get(i));
                adapter.notifyDataSetChanged();
            }
        });
        ;

    }
}