package ch.walica.temp230925_4tp2_snackbar;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton floatingActionButton;
    private Button btnShow;
    private ConstraintLayout constraintLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        floatingActionButton = findViewById(R.id.floatingActionButton);
        btnShow = findViewById(R.id.btnShow);
        constraintLayout = findViewById(R.id.main);

        Snackbar snackbar = Snackbar
                .make(constraintLayout, "Coś napisać trzeba", Snackbar.LENGTH_INDEFINITE)
                .setAnchorView(btnShow);

        snackbar.show();

        btnShow.setOnClickListener(view -> {
            Snackbar.make(floatingActionButton, "To jest Snackbar", Snackbar.LENGTH_LONG)
                    .setTextColor(Color.YELLOW)
                    .setBackgroundTint(Color.DKGRAY)
                    .setAnimationMode(Snackbar.ANIMATION_MODE_SLIDE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setAnchorView(floatingActionButton)
                    .show();
        });
    }
}