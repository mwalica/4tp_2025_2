package ch.walica.a31_temp160126_4tp2_json;

import android.app.Activity;

import java.io.IOException;
import java.io.InputStream;

public class Util {
    public static String loadJSONFromAssets(Activity activity, String fileName) {
        String json = null;
        try {
            InputStream inputStream = activity.getAssets().open(fileName);
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.getLocalizedMessage();
            return null;
        }
        return json;
    }
}
