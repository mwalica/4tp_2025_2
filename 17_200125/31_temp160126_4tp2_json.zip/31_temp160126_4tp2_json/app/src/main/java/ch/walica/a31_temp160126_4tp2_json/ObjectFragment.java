package ch.walica.a31_temp160126_4tp2_json;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;


public class ObjectFragment extends Fragment {

    private String json = "{\n" +
            "  \"firstName\": \"Jan\",\n" +
            "  \"age\": 23,\n" +
            "  \"address\" : {\n" +
            "    \"city\": \"Katowice\",\n" +
            "    \"country\": \"Polska\"\n" +
            "  }\n" +
            "}";

    private Button btnShow;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_object, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnShow = view.findViewById(R.id.btnShow);

        btnShow.setOnClickListener(v -> {
            try {
                JSONObject personObj = new JSONObject(Util.loadJSONFromAssets(requireActivity(), "person.json"));
                String firstName = personObj.getString("firstName");
                int age = personObj.getInt("age");
                JSONObject address = personObj.getJSONObject("address");
                String city = address.getString("city");
                String country = address.getString("country");
                String msg = firstName + " " + age + " " + city + " " + country;
                Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
            } catch(JSONException error) {
                Toast.makeText(getContext(), error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }

        });
    }

}