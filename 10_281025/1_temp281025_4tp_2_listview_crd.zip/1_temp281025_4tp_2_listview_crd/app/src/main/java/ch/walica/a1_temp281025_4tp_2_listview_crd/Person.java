package ch.walica.a1_temp281025_4tp_2_listview_crd;

import androidx.annotation.NonNull;

import java.util.Random;

public class Person {
    String name;
    int age;

    public Person(String name) {
        this.name = name;
        this.age = new Random().nextInt(70) + 18;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @NonNull
    @Override
    public String toString() {
        return name + " " + age;
    }
}
