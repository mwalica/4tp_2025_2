package ch.walica.a1_temp281025_4tp_2_listview_crd;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private EditText etName;
    private Button btnAdd;
    private List<Person> people = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);
        etName = findViewById(R.id.etName);
        btnAdd = findViewById(R.id.btnAdd);

        people.add(new Person("Jan"));

        ArrayAdapter<Person> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, people);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                people.remove(i);
                adapter.notifyDataSetChanged();
            }
        });

        btnAdd.setOnClickListener(view -> {
            String name = etName.getText().toString().trim();
            if (!name.isEmpty()) {
                people.add(new Person(name));
                adapter.notifyDataSetChanged();
                etName.getText().clear();
            }
        });
    }
}