package ch.walica.egzaminacyjne_czerwiec_2024;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView iv1, iv2, iv3, iv4, iv5;
    Button btnRandom, btnReset;
    TextView tvResult1, tvResult2;
    Random random = new Random();
    int[] numbers = new int[5];
    int result = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        iv1 = findViewById(R.id.iv1);
        iv2 = findViewById(R.id.iv2);
        iv3 = findViewById(R.id.iv3);
        iv4 = findViewById(R.id.iv4);
        iv5 = findViewById(R.id.iv5);
        btnRandom = findViewById(R.id.btnRandom);
        btnReset = findViewById(R.id.btnReset);

        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);

        btnRandom.setOnClickListener(view -> {
            for (int i = 0; i < numbers.length; i++) {
                numbers[i] = random.nextInt(6) + 1;
            }


            iv1.setImageResource(setPhoto(numbers[0]));
            iv2.setImageResource(setPhoto(numbers[1]));
            iv3.setImageResource(setPhoto(numbers[2]));
            iv4.setImageResource(setPhoto(numbers[3]));
            iv5.setImageResource(setPhoto(numbers[4]));

            int sum = calc();
            result += sum;
            tvResult1.setText("Wynik tego losowania: " + sum);
            tvResult2.setText("Wynik gry: " + result);
        });

        btnReset.setOnClickListener(view -> {
            result = 0;
            tvResult1.setText("Wynik tego losowania: 0");
            tvResult2.setText("Wynik gry: " + result);
            numbers = new int[5];
            iv1.setImageResource(setPhoto(numbers[0]));
            iv2.setImageResource(setPhoto(numbers[1]));
            iv3.setImageResource(setPhoto(numbers[2]));
            iv4.setImageResource(setPhoto(numbers[3]));
            iv5.setImageResource(setPhoto(numbers[4]));

        });

    }

    private int setPhoto(int num) {
        return switch (num) {
            case 1 -> R.drawable.k1;
            case 2 -> R.drawable.k2;
            case 3 -> R.drawable.k3;
            case 4 -> R.drawable.k4;
            case 5 -> R.drawable.k5;
            case 6 -> R.drawable.k6;
            default -> R.drawable.question;
        };
    }

    private int calc() {
//        HashSet<Integer> duplicates = new HashSet<>();
        List<Integer> duplicates = new ArrayList<>();
        int sum = 0;
        for (int i = 0; i < numbers.length; i++) {
            for (int j = i + 1; j < numbers.length; j++) {
                if (numbers[i] == numbers[j] && !duplicates.contains(numbers[i])) {
                    duplicates.add(numbers[i]);
                }
            }
        }
        Log.d("my_log", "duplicates: " + duplicates);

        if (!duplicates.isEmpty()) {
            for (Integer num : duplicates) {
                for (int item : numbers) {
                    if (item == num) {
                        sum += num;
                        Log.d("my_log", "calc: Wykonane");
                    }
                }
            }
        }
        return sum;
    }
}