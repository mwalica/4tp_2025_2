package ch.walica.a14_temp211125_4tp_2_rv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.PersonViewHolder> {

    private List<Person> people;
    private OnPersonClickListener onPersonClickListener;

    public PersonAdapter(List<Person> people, OnPersonClickListener onPersonClickListener) {
        this.people = people;
        this.onPersonClickListener = onPersonClickListener;
    }

    @NonNull
    @Override
    public PersonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.person_item, parent, false);
        return new PersonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonViewHolder holder, int position) {
        holder.bind(people.get(position));
    }

    @Override
    public int getItemCount() {
        return people.size();
    }


    class PersonViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView tvName, tvAge;
        ImageView ivDelete;

        public PersonViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvAge = itemView.findViewById(R.id.tvAge);
            ivDelete = itemView.findViewById(R.id.ivDelete);

            ivDelete.setOnClickListener(this);
        }

        public void bind(Person person) {
            tvName.setText(person.getName());
            tvAge.setText(person.getAge() + " lat");
        }

        @Override
        public void onClick(View view) {
            onPersonClickListener.onPersonClick(getBindingAdapterPosition());
        }
    }
}
