package ch.walica.a14_temp211125_4tp_2_rv;

public interface OnPersonClickListener {
    public void onPersonClick(int position);
}
