package ch.walica.a16_temp251125_4tp_2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Random;

public class NumberAdapter extends RecyclerView.Adapter<NumberAdapter.NumberViewHolder> {

    private List<Integer> numbers;
    private int itemLayout;

    public NumberAdapter(List<Integer> numbers, int itemLayout) {
        this.numbers = numbers;
        this.itemLayout = itemLayout;
    }

    @NonNull
    @Override
    public NumberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(itemLayout, parent, false);
        return new NumberViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NumberViewHolder holder, int position) {
        holder.bind(numbers.get(position));
    }

    @Override
    public int getItemCount() {
        return numbers.size();
    }

    public class NumberViewHolder extends RecyclerView.ViewHolder {

        private TextView tvNumber;

        public NumberViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNumber = itemView.findViewById(R.id.tvNumber);

        }

        public void bind(int number) {
            tvNumber.setText(String.valueOf(number));
            tvNumber.setTextSize(number * new Random().nextInt(6) + 1);
        }
    }
}
