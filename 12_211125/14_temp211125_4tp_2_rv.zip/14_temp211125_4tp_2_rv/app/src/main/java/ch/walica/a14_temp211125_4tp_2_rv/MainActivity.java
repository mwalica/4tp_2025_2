package ch.walica.a14_temp211125_4tp_2_rv;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText etName;
    private Button btnAdd;
    private List<Person> people = new ArrayList<>();
    private PersonAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        etName = findViewById(R.id.etName);
        btnAdd = findViewById(R.id.btnAdd);

        people.add(new Person("Jan"));
        people.add(new Person("Anna"));
        people.add(new Person("Gustaw"));
        people.add(new Person("Katarzyna"));
        people.add(new Person("Ludmiła"));
        people.add(new Person("Adam"));
        people.add(new Person("Lucjan"));

        //ustawienie układu listy
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        adapter = new PersonAdapter(people);
        recyclerView.setAdapter(adapter);

        btnAdd.setOnClickListener(view -> {
            String name = etName.getText().toString().trim();
            if(!name.isEmpty()) {
                people.add(new Person(name));
                etName.getText().clear();
                adapter.notifyDataSetChanged();
            }
        });

    }
}